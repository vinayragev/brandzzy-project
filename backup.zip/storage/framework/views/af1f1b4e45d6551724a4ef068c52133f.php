<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  <h1 class="h2">User / List </h1>
  <div class="btn-toolbar mb-2 mb-md-0">
    <a href="/user_add.php" class="btn btn-outline-secondary">Add User</a>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vs/php/brandzzy-lara/resources/views/admin/index.blade.php ENDPATH**/ ?>